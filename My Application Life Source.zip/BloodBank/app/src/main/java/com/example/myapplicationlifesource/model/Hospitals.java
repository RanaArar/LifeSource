package com.example.myapplicationlifesource.model;

import java.util.ArrayList;

public class Hospitals {
    ArrayList<String> hospitalsArray;

    public Hospitals() {
    }

    public ArrayList<String> getHospitalsArray() {
        return hospitalsArray;
    }

    public void setHospitalsArray(ArrayList<String> hospitalsArray) {
        this.hospitalsArray = hospitalsArray;
    }
}
