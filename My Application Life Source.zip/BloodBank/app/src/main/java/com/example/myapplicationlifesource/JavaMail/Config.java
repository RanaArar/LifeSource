package com.example.myapplicationlifesource.JavaMail;

public class Config {
    public static String EMAIL = "lifesaverproject.000@gmail.com";
    public static String PASSWORD = "lifesaver1234@";
    public static final String sentToEmail = "lifesaverproject@hotmail.com";//"rana997.ra@gmail.com";

}
